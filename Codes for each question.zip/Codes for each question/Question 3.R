ggplot(data, aes(x = academic_performance)) +
  geom_bar(fill = "#443785") +
  labs(title = "Distribution of Academic Performance")
