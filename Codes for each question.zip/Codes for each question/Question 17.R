table(data$extracurricular_activities, data$academic_performance)
