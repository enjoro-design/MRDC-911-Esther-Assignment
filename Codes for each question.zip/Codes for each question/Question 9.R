missing_summary <- sapply(data, function(x) sum(is.na(x)) / length(x) * 100)
missing_summary[missing_summary > 0]
missing_summary <- sapply(data, function(x) sum(is.na(x)) / length(x) * 100)  
missing_summary[missing_summary > 0]  
