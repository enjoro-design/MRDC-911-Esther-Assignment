install.packages(c("tidyverse", "ggplot2",)
library(tidyverse)
library(ggplot2)
library(corrplot)
library(tidyverse)

kenya_data <- read_csv("kenya_student_data.csv")
